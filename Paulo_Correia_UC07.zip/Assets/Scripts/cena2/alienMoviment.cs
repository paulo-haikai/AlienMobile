﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class alienMoviment : MonoBehaviour
{
    public float speed = 5f;


   

    
}
